# راه‌اندازی ساخت ابری فوت کینگ از طریق GitHub (با گوشی)

## نکته مهم
برای اجرای GitHub Actions لازم است فایل workflow در خود مخزن GitHub قرار داشته باشد. صرف بارگذاری ZIP به‌تنهایی workflow را فعال نمی‌کند. این پروژه از Gradle نصب‌شده در runner استفاده می‌کند؛ بنابراین وجود فایل `gradlew` برای همین workflow الزامی نیست.

## روش ساده با گوشی
1. فایل ZIP سورس را در ریشه مخزن GitHub بارگذاری کنید. نام فایل را به `FootKing-Cloud-Build-Stage.zip` تغییر دهید یا همان نام `FootKing-Cloud-Build-Stage-2.zip` را حفظ کنید.
2. در مخزن، گزینه Add file > Create new file را انتخاب کنید.
3. نام فایل جدید را دقیقاً وارد کنید: `.github/workflows/build-footking.yml`
4. محتوای فایل را از بخش «محتوای workflow» در فایل `GITHUB-WORKFLOW-CONTENT-FA.txt` کپی کنید و در ویرایشگر GitHub بچسبانید.
5. پایین صفحه Commit changes را بزنید.
6. از زبانه Actions اجرای `Build FootKing APK` را باز کنید. با push فایل ZIP نیز workflow اجرا می‌شود.
7. اگر ساخت موفق شد، در صفحه اجرای workflow به بخش Artifacts بروید و `footking-debug-apk` را دریافت کنید. فایل داخل آن `app-debug.apk` است.

## محدودیت‌های فعلی
- این فرایند فقط ساخت APK آزمایشی (debug) را هدف می‌گیرد، نه نسخه امضاشده برای انتشار عمومی.
- پروژه Firebase واقعی و فایل `google-services.json` هنوز باید توسط مالک پروژه تنظیم شود؛ ساخت APK به‌تنهایی فعال‌شدن ورود پیامکی یا Firestore را تضمین نمی‌کند.
- تا زمانی که اجرای GitHub Actions با وضعیت سبز و نصب APK روی گوشی تأیید نشود، نباید گفت APK ساخته و آزمایش شده است.
