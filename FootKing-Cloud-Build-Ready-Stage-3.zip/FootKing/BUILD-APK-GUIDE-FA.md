# راهنمای ساخت APK فوت کینگ

## وضعیت این نسخه
این ZIP سورس یکپارچه فعلی پروژه است، نه فایل نصب APK. در محیط آماده‌سازی فعلی Android SDK و ابزار کامل ساخت اندروید موجود نبود؛ بنابراین APK ساخته یا کامپایل تأیید نشده است.

## ساخت نسخه آزمایشی با Android Studio
1. Android Studio را نصب کنید و JDK 17 و Android SDK Platform 35 را از SDK Manager دریافت کنید.
2. پوشه `FootKing` را در Android Studio باز کنید.
3. منتظر بمانید Gradle Sync کامل شود. اگر Android Studio نصب SDK یا Build Tools را درخواست کرد، همان نسخه پیشنهادی را نصب کنید.
4. برای ساخت نسخه نمایشی، لازم نیست اطلاعات Firebase شخص دیگری را وارد کنید. تا زمان افزودن فایل واقعی `app/google-services.json` قابلیت‌های آنلاین Firebase فعال نخواهند بود.
5. از منوی **Build > Build Bundle(s) / APK(s) > Build APK(s)** خروجی بگیرید.
6. در صورت موفقیت، فایل معمولاً در مسیر `app/build/outputs/apk/debug/app-debug.apk` قرار می‌گیرد.

## برای فعال‌شدن قابلیت‌های آنلاین
- فایل `google-services.json` را از پروژه Firebase متعلق به مالک برنامه دریافت و در پوشه `app/` قرار دهید.
- Phone Authentication و Cloud Firestore را در Firebase فعال کنید.
- قوانین `backend/firestore/firestore.rules` و توابع سرور را پس از بازبینی در پروژه واقعی منتشر کنید.
- آدرس API نمونه را با آدرس HTTPS سرور واقعی جایگزین کنید.

## نکته امنیتی
برای انتشار عمومی، نقش مدیر باید فقط از سمت سرور و با custom claim معتبر اعطا شود. رمز مدیر یا کلید خصوصی را داخل کد اندروید قرار ندهید.
