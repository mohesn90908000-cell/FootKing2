# FOOT KING — Firestore Profile Stage

## Implemented
- Added the Firebase Firestore Android dependency.
- Added `ProfileRepository` to load and save a signed-in user's profile at `profiles/{uid}`.
- Added editable display name, username, favorite team, and short bio fields to the profile screen.
- Added basic validation for display name, username format, and text lengths.
- Updated Firestore rules to allow the owner to update the added profile fields while keeping profile deletion restricted to the admin claim.
- Uses server timestamp for `updatedAt`.

## Firebase setup still required
- Add the real `google-services.json` and configure the Google Services Gradle plugin as described in the prior authentication stage.
- Create/enable Firestore Database in the Firebase console.
- Deploy `backend/firestore/firestore.rules` before testing writes.
- Ensure the user is signed in with Firebase Phone Authentication.

## Important limitations
- Username uniqueness is not enforced yet; it needs a trusted backend transaction or callable function and a dedicated username index.
- Profile documents are readable publicly under the current rules. Do not store private contact details or sensitive information in these documents.
- Profile photo upload is not included; it requires Firebase Storage and corresponding rules.
- Existing points, prediction totals, and badges remain demo values and are not changed by this stage.
- No Firebase project was available, so Firestore reads/writes were not deployed or live-tested.
- No Gradle build, emulator test, or physical-device test was run in this environment.
