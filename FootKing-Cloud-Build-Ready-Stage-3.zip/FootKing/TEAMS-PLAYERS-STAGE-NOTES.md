# Foot King - Teams & Players Stage

Added to the existing News stage:
- searchable team directory
- team detail view with country, competition, founded year, stadium and coach placeholders
- sample roster per team
- player detail view with position, shirt number, age, goals, assists and rating
- navigation between team list, team detail and player detail

Important: all team/player names and statistics in this stage are demo placeholders, not verified real-world data. No live sports provider, database persistence, or admin editing is connected. Android build/compilation has not been run in this environment.
