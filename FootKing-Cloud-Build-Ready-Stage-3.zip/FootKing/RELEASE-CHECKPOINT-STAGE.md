# FOOT KING — Release checkpoint stage

## Changes in this stage
- Removed the demo admin-panel entry from the public profile screen. The old in-app demo admin screen is no longer reachable through normal navigation; a production admin panel must only be exposed after server-verified admin authorization.
- Prevented the app from sending health-check requests to the placeholder `api.example.com` endpoint.
- Added a distinct `NotConfigured` API state so the home screen can explain that the backend URL has not been configured yet.

## What this does not mean
- This is not an APK and has not been compiled or device-tested.
- Firebase is still not configured for a real project.
- Live sports data, persistent admin operations, and production admin claims are not active.
- The project still needs Android Studio/Android SDK and a successful Gradle build before an installable APK can be delivered.

## Next required action
Open the project in Android Studio, sync Gradle, and run a debug build. Resolve any compiler/build errors from the actual build output before creating the APK.
