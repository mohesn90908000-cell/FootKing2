# FOOT KING — Release preparation status

## What this package contains
- The latest consolidated Android source available in this workspace (Kotlin + Jetpack Compose).
- Match, teams/players, news, predictions, profile, phone-auth adapter, Firestore profile repository, and admin/backend starter files from the previous stages.
- A single build checklist for producing a debug APK.

## Important: APK was not built in this environment
This workspace does not have Android SDK / Android Gradle Plugin build tooling configured, and the project has no Gradle wrapper. Therefore no APK has been generated or compile-tested here. Do not treat this ZIP as an installable APK.

## Required to build a debug APK
1. Install Android Studio with Android SDK Platform 35 and a compatible JDK (JDK 17).
2. Open this `FootKing` folder in Android Studio and allow Gradle sync to finish.
3. If Gradle reports missing SDK, install the SDK platform/build-tools requested by Android Studio.
4. For a demo build, Firebase screens should report that Firebase is not configured until a real `google-services.json` is added. Do not invent or use another project's config.
5. Select **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
6. The debug APK, if the build succeeds, is normally created at `app/build/outputs/apk/debug/app-debug.apk`.

## Required before real public launch
- Add the owner's actual Firebase `google-services.json` and apply the Google Services Gradle plugin.
- Enable Phone Authentication and Firestore in the Firebase console.
- Deploy and review Firestore rules and Cloud Functions; configure admin custom claims securely.
- Replace the placeholder API URL with a real HTTPS backend, or disable online status checks until a backend exists.
- Connect live match/league/news data to a licensed provider or verified admin workflow.
- Test login, profile writes, predictions, admin authorization, and offline/error states on real devices.

## Current limitations
- No live sports data provider or production backend is configured.
- Firebase is not connected to a real project in this package.
- Admin authorization is not production-ready until the trusted custom claim is provisioned server-side.
- Some app content remains sample/demo data.
- No APK signing/release keystore is included. Never share a private signing key in chat.

## Latest release checkpoint
See `RELEASE-CHECKPOINT-STAGE.md`. The demo admin entry has been removed from public navigation, and placeholder API health checks are suppressed until a real backend URL is supplied.
