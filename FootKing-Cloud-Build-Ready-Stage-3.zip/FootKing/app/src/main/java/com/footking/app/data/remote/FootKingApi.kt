package com.footking.app.data.remote

import com.google.gson.JsonArray
import com.google.gson.JsonObject
import retrofit2.Response
import retrofit2.http.GET

/**
 * Public endpoints currently defined for the FOOT KING backend.
 * Authenticated endpoints will be added after the server session contract is finalized.
 */
interface FootKingApi {
    @GET("api/health")
    suspend fun health(): Response<JsonObject>

    @GET("api/matches")
    suspend fun matches(): Response<JsonArray>

    @GET("api/leaderboard")
    suspend fun leaderboard(): Response<JsonArray>

    @GET("api/catalog/leagues")
    suspend fun leagues(): Response<JsonArray>

    @GET("api/competitions")
    suspend fun competitions(): Response<JsonArray>
}
