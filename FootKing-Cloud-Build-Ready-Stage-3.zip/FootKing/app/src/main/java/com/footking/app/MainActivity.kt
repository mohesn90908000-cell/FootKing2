package com.footking.app

import android.os.Bundle
import android.app.Activity
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.delay
import com.footking.app.data.remote.ApiConnectionState
import com.footking.app.data.remote.ApiRepository
import com.footking.app.auth.PhoneAuthManager
import com.footking.app.data.profile.ProfileRepository
import com.google.firebase.auth.PhoneAuthProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.text.KeyboardOptions

private val Ink = Color(0xFF090B10)
private val Panel = Color(0xFF151922)
private val Gold = Color(0xFFD8B15A)
private val Muted = Color(0xFF9AA1AD)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MaterialTheme(colorScheme = darkColorScheme(primary = Gold, background = Ink, surface = Panel)) { FootKingApp(this) } }
    }
}

private enum class Tab(val title: String, val icon: ImageVector) {
    Home("خانه", Icons.Default.Home), Matches("مسابقات", Icons.Default.SportsSoccer), Predictions("پیش‌بینی", Icons.Default.Campaign),
    Teams("تیم‌ها", Icons.Default.Groups), Table("جدول لیگ", Icons.Default.EmojiEvents), News("اخبار", Icons.Default.Article), Profile("پروفایل", Icons.Default.Person)
}

@Composable
private fun FootKingApp(activity: Activity) {
    var selected by remember { mutableStateOf(Tab.Home) }
    var selectedMatch by remember { mutableStateOf<String?>(null) }
    var apiConnected by remember { mutableStateOf<Boolean?>(null) }
    val apiRepository = remember { ApiRepository() }
    LaunchedEffect(Unit) {
        while (true) {
            apiConnected = when (apiRepository.checkConnection()) {
                is ApiConnectionState.Connected -> true
                is ApiConnectionState.Unavailable -> false
                is ApiConnectionState.NotConfigured -> null
            }
            delay(30_000)
        }
    }
    CompositionLocalProvider(androidx.compose.ui.platform.LocalLayoutDirection provides androidx.compose.ui.unit.LayoutDirection.Rtl) {
        Scaffold(containerColor = Ink, bottomBar = {
            NavigationBar(containerColor = Panel, contentColor = Gold) {
                Tab.entries.forEach { tab ->
                    NavigationBarItem(selected = selected == tab, onClick = { selected = tab },
                        icon = { Icon(tab.icon, contentDescription = tab.title) },
                        label = { Text(tab.title, fontSize = 10.sp) },
                        colors = NavigationBarItemDefaults.colors(selectedIconColor = Ink, selectedTextColor = Gold,
                            indicatorColor = Gold, unselectedIconColor = Muted, unselectedTextColor = Muted))
                }
            }
        }) { padding ->
            LazyColumn(modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp),
                contentPadding = PaddingValues(top = 18.dp, bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                item { Header() }
                item { ApiConnectionCard(apiConnected) }
                when (selected) {
                    Tab.Home -> {
                        item { HeroCard() }
                        item { SectionTitle("دسترسی سریع", "همه بخش‌های فوت کینگ") }
                        item { QuickGrid(onSelect = { selected = it }) }
                        item { SectionTitle("مسابقات پیش‌رو", "مشاهده همه") }
                        item { MatchCard("پرسپولیس", "استقلال", "جمعه • ۱۹:۳۰", "لیگ برتر") }
                        item { SectionTitle("جدول لیگ", "جدول کامل") }
                        item { StandingsCard() }
                    }
                    Tab.Matches -> {
                        item {
                            if (selectedMatch == null) {
                                Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                                    SectionTitle("مسابقات", "برنامه و نتایج")
                                    MatchCard("پرسپولیس", "استقلال", "جمعه • ۱۹:۳۰", "لیگ برتر") { selectedMatch = "پرسپولیس|استقلال|جمعه • ۱۹:۳۰|لیگ برتر" }
                                    MatchCard("سپاهان", "تراکتور", "شنبه • ۱۸:۰۰", "لیگ برتر") { selectedMatch = "سپاهان|تراکتور|شنبه • ۱۸:۰۰|لیگ برتر" }
                                    MatchCard("رئال مادرید", "بارسلونا", "یکشنبه • ۲۲:۳۰", "لالیگا") { selectedMatch = "رئال مادرید|بارسلونا|یکشنبه • ۲۲:۳۰|لالیگا" }
                                    Text("برای مشاهده جزئیات، مسابقه‌ای را انتخاب کن.", color = Muted, fontSize = 10.sp)
                                }
                            } else {
                                MatchDetailScreen(selectedMatch!!) { selectedMatch = null }
                            }
                        }
                    }
                    Tab.Predictions -> { item { PredictionCenterScreen() } }
                    Tab.Teams -> { item { TeamDirectoryScreen() } }
                    Tab.Table -> { item { SectionTitle("جدول رده‌بندی", "لیگ برتر") }; item { StandingsCard() } }
                    Tab.News -> { item { NewsCenterScreen() } }
                    Tab.Profile -> { item { ProfileDashboardScreen(activity = activity) } }
                }
                item { Text("فوت کینگ • پادشاه دنیای فوتبال", color = Muted, fontSize = 11.sp, modifier = Modifier.fillMaxWidth().padding(top = 8.dp), textAlign = TextAlign.Center) }
            }
        }
    }
}

@Composable private fun ApiConnectionCard(connected: Boolean?) {
    val label = when (connected) {
        null -> "سرور هنوز برای فوت کینگ تنظیم نشده است"
        true -> "ارتباط با سرور برقرار است"
        false -> "سرور در دسترس نیست؛ اتصال بعداً دوباره بررسی می‌شود"
    }
    val dotColor = when (connected) {
        null -> Muted
        true -> Color(0xFF55C78A)
        false -> Color(0xFFE06C6C)
    }
    Row(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(12.dp)).padding(horizontal = 14.dp, vertical = 11.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(9.dp)
    ) {
        Box(Modifier.size(8.dp).background(dotColor, CircleShape))
        Text(label, color = Muted, fontSize = 10.sp)
    }
}

@Composable private fun Header() {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(Modifier.size(46.dp).background(Gold, RoundedCornerShape(14.dp)), contentAlignment = Alignment.Center) { Icon(Icons.Default.EmojiEvents, null, tint = Ink, modifier = Modifier.size(27.dp)) }
            Column { Text("فوت کینگ", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Black); Text("FOOT KING", color = Muted, fontSize = 9.sp, letterSpacing = 2.sp) }
        }
        IconButton(onClick = {}) { Icon(Icons.Default.NotificationsNone, "اعلان‌ها", tint = Gold) }
    }
}

@Composable private fun HeroCard() {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp)).padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        Text("به دنیای فوتبال خوش آمدی", color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
        Text("همه چیز درباره فوتبال،\nدر یک برنامه", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 32.sp)
        Text("مسابقات، تیم‌ها، آمار و اخبار فوتبال", color = Muted, fontSize = 12.sp)
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) { Text("●  همراه فوتبال باش", color = Gold, fontSize = 11.sp) }
    }
}

@Composable private fun SectionTitle(title: String, action: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(title, color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
        Text(action, color = Gold, fontSize = 11.sp)
    }
}

@Composable private fun QuickGrid(onSelect: (Tab) -> Unit) {
    val items = listOf(Tab.Matches, Tab.Teams, Tab.Table, Tab.News)
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        items.chunked(2).forEach { row -> Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            row.forEach { tab -> Column(Modifier.weight(1f).background(Panel, RoundedCornerShape(16.dp)).clickable { onSelect(tab) }.padding(16.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Icon(tab.icon, null, tint = Gold, modifier = Modifier.size(26.dp)); Text(tab.title, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            } }
        } }
    }
}

@Composable private fun MatchCard(home: String, away: String, time: String, league: String, onClick: () -> Unit = {}) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).clickable { onClick() }.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text(league, color = Gold, fontSize = 11.sp); Text(time, color = Muted, fontSize = 11.sp) }
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically) {
            TeamBadge(home); Text("VS", color = Gold, fontWeight = FontWeight.Black, fontSize = 14.sp); TeamBadge(away)
        }
    }
}



@Composable
private fun MatchDetailScreen(match: String, onBack: () -> Unit) {
    val parts = match.split("|")
    val home = parts.getOrElse(0) { "تیم میزبان" }
    val away = parts.getOrElse(1) { "تیم میهمان" }
    val time = parts.getOrElse(2) { "زمان نامشخص" }
    val league = parts.getOrElse(3) { "مسابقه" }
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowForward, "بازگشت", tint = Gold) }
            Column { Text("جزئیات مسابقه", color = Color.White, fontWeight = FontWeight.Bold); Text(league, color = Muted, fontSize = 10.sp) }
        }
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text(league, color = Gold, fontSize = 11.sp)
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically) {
                TeamBadge(home)
                Column(horizontalAlignment = Alignment.CenterHorizontally) { Text("VS", color = Gold, fontSize = 22.sp, fontWeight = FontWeight.Black); Text("در انتظار شروع", color = Muted, fontSize = 10.sp) }
                TeamBadge(away)
            }
            Text(time, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
            Text("اطلاعات این مسابقه در حال حاضر نمونه است.", color = Muted, fontSize = 10.sp)
        }
        SectionTitle("آمار مسابقه", "آمار رسمی پس از اتصال سرور")
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(15.dp), verticalArrangement = Arrangement.spacedBy(13.dp)) {
            MatchStatRow("مالکیت توپ", "۵۰٪", "۵۰٪")
            MatchStatRow("شوت", "۰", "۰")
            MatchStatRow("شوت در چارچوب", "۰", "۰")
            MatchStatRow("کرنر", "۰", "۰")
            MatchStatRow("کارت زرد", "۰", "۰")
        }
        SectionTitle("رویدادهای مسابقه", "گزارش بازی")
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("هنوز رویدادی برای این مسابقه ثبت نشده است.", color = Muted, fontSize = 11.sp)
            Text("گل‌ها، کارت‌ها و تعویض‌ها پس از دریافت اطلاعات معتبر نمایش داده می‌شوند.", color = Muted, fontSize = 10.sp)
        }
        SectionTitle("ترکیب تیم‌ها", "ترکیب رسمی")
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(15.dp)) {
            Text("ترکیب دو تیم هنوز اعلام نشده است.", color = Muted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun MatchStatRow(label: String, home: String, away: String) {
    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(home, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            Text(label, color = Muted, fontSize = 10.sp)
            Text(away, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
        }
        Row(Modifier.fillMaxWidth().height(5.dp).background(Color(0xFF343A45), RoundedCornerShape(8.dp))) {
            Box(Modifier.weight(1f).fillMaxHeight().background(Gold, RoundedCornerShape(8.dp)))
            Spacer(Modifier.width(3.dp))
            Box(Modifier.weight(1f).fillMaxHeight().background(Gold, RoundedCornerShape(8.dp)))
        }
    }
}

@Composable private fun TeamBadge(name: String) {
    Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Box(Modifier.size(42.dp).background(Color(0xFF252B35), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Shield, null, tint = Gold) }
        Text(name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable private fun StandingsCard() {
    val rows = listOf("پرسپولیس" to "۲۸", "استقلال" to "۲۶", "سپاهان" to "۲۴", "تراکتور" to "۲۲")
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) { Text("تیم", color = Muted, fontSize = 11.sp); Text("امتیاز", color = Muted, fontSize = 11.sp) }
        rows.forEachIndexed { index, row -> Row(Modifier.fillMaxWidth().background(if (index == 0) Color(0xFF28251D) else Color.Transparent, RoundedCornerShape(9.dp)).padding(10.dp), horizontalArrangement = Arrangement.SpaceBetween) {
            Text("${index + 1}   ${row.first}", color = Color.White, fontSize = 12.sp); Text(row.second, color = Gold, fontWeight = FontWeight.Bold)
        } }
    }
}

@Composable private fun TeamRow(name: String, subtitle: String, players: String) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Default.Shield, null, tint = Gold, modifier = Modifier.size(32.dp)); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(name, color = Color.White, fontWeight = FontWeight.Bold); Text(subtitle, color = Muted, fontSize = 10.sp) }; Text(players, color = Gold, fontSize = 10.sp)
    }
}



private data class FootKingPlayer(
    val name: String, val position: String, val number: Int, val age: Int,
    val goals: Int, val assists: Int, val rating: String
)

private data class FootKingTeam(
    val name: String, val country: String, val league: String, val founded: String,
    val stadium: String, val coach: String, val players: List<FootKingPlayer>
)

@Composable
private fun TeamDirectoryScreen() {
    val teams = remember {
        listOf(
            FootKingTeam("پرسپولیس", "ایران", "لیگ برتر", "۱۳۴۲", "آزادی", "اطلاعات نمونه", listOf(
                FootKingPlayer("مهدی احمدی", "دروازه‌بان", 1, 27, 0, 0, "۷.۴"),
                FootKingPlayer("علی رضایی", "مدافع", 4, 25, 1, 2, "۷.۱"),
                FootKingPlayer("امیر کریمی", "هافبک", 8, 24, 3, 4, "۷.۸"),
                FootKingPlayer("رضا محمدی", "مهاجم", 9, 23, 7, 1, "۸.۱")
            )),
            FootKingTeam("استقلال", "ایران", "لیگ برتر", "۱۳۲۴", "آزادی", "اطلاعات نمونه", listOf(
                FootKingPlayer("پارسا حسینی", "دروازه‌بان", 1, 26, 0, 0, "۷.۳"),
                FootKingPlayer("آرمان صالحی", "مدافع", 5, 28, 1, 1, "۷.۲"),
                FootKingPlayer("سامان نوری", "هافبک", 7, 24, 2, 5, "۷.۷"),
                FootKingPlayer("یاسین مرادی", "مهاجم", 10, 22, 6, 2, "۸.۰")
            )),
            FootKingTeam("سپاهان", "ایران", "لیگ برتر", "۱۳۳۲", "نقش جهان", "اطلاعات نمونه", listOf(
                FootKingPlayer("کیان رستمی", "دروازه‌بان", 1, 27, 0, 0, "۷.۵"),
                FootKingPlayer("بردیا اکبری", "مدافع", 3, 26, 1, 0, "۷.۲"),
                FootKingPlayer("شایان قاسمی", "هافبک", 6, 25, 4, 3, "۷.۹"),
                FootKingPlayer("نیما جعفری", "مهاجم", 11, 23, 5, 2, "۷.۸")
            ))
        )
    }
    var query by remember { mutableStateOf("") }
    var selectedTeam by remember { mutableStateOf<FootKingTeam?>(null) }
    var selectedPlayer by remember { mutableStateOf<FootKingPlayer?>(null) }
    Column(verticalArrangement = Arrangement.spacedBy(13.dp)) {
        if (selectedPlayer != null) {
            val player = selectedPlayer!!
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { selectedPlayer = null }) { Icon(Icons.Default.ArrowBack, "بازگشت", tint = Gold) }
                Text("پروفایل بازیکن", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(18.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Box(Modifier.size(76.dp).background(Color(0xFF28251D), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Person, null, tint = Gold, modifier = Modifier.size(42.dp)) }
                Text(player.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                Text("${player.position} • شماره ${player.number}", color = Gold, fontSize = 12.sp)
                Text("سن ${player.age} سال", color = Muted, fontSize = 11.sp)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                PlayerStat("گل", player.goals.toString(), Modifier.weight(1f))
                PlayerStat("پاس گل", player.assists.toString(), Modifier.weight(1f))
                PlayerStat("امتیاز", player.rating, Modifier.weight(1f))
            }
            Text("آمار این بازیکن نمونه و نمایشی است و هنوز از منبع رسمی دریافت نمی‌شود.", color = Muted, fontSize = 10.sp)
        } else if (selectedTeam != null) {
            val team = selectedTeam!!
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = { selectedTeam = null }) { Icon(Icons.Default.ArrowBack, "بازگشت", tint = Gold) }
                Text("جزئیات تیم", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
            }
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(17.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Box(Modifier.size(54.dp).background(Color(0xFF28251D), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Shield, null, tint = Gold, modifier = Modifier.size(30.dp)) }
                    Column { Text(team.name, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold); Text("${team.country} • ${team.league}", color = Gold, fontSize = 11.sp) }
                }
                Divider(color = Color(0xFF303642))
                Text("سال تأسیس: ${team.founded}     ورزشگاه: ${team.stadium}", color = Muted, fontSize = 11.sp)
                Text("سرمربی: ${team.coach}", color = Muted, fontSize = 11.sp)
            }
            Text("فهرست بازیکنان", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
            team.players.forEach { player -> PlayerRow(player) { selectedPlayer = player } }
        } else {
            Text("تیم‌ها و بازیکنان", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
            Text("باشگاه‌ها را انتخاب کن و فهرست بازیکنان را ببین", color = Muted, fontSize = 11.sp)
            OutlinedTextField(value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true,
                placeholder = { Text("جست‌وجوی تیم", color = Muted) }, leadingIcon = { Icon(Icons.Default.Search, null, tint = Gold) },
                colors = OutlinedTextFieldDefaults.colors(focusedTextColor = Color.White, unfocusedTextColor = Color.White, focusedBorderColor = Gold, unfocusedBorderColor = Muted))
            teams.filter { it.name.contains(query.trim(), ignoreCase = true) }.forEach { team ->
                Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).clickable { selectedTeam = team }.padding(15.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(46.dp).background(Color(0xFF28251D), CircleShape), contentAlignment = Alignment.Center) { Icon(Icons.Default.Shield, null, tint = Gold, modifier = Modifier.size(25.dp)) }
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) { Text(team.name, color = Color.White, fontWeight = FontWeight.Bold); Text("${team.country} • ${team.league}", color = Muted, fontSize = 10.sp); Text("${team.players.size} بازیکن در فهرست نمونه", color = Gold, fontSize = 10.sp) }
                    Icon(Icons.Default.ChevronLeft, null, tint = Gold)
                }
            }
            Text("نام‌ها و آمار این نسخه صرفاً داده‌های نمایشی هستند.", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun PlayerRow(player: FootKingPlayer, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).clickable { onClick() }.padding(13.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(40.dp).background(Color(0xFF28251D), CircleShape), contentAlignment = Alignment.Center) { Text(player.number.toString(), color = Gold, fontWeight = FontWeight.Bold) }
        Spacer(Modifier.width(10.dp))
        Column(Modifier.weight(1f)) { Text(player.name, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp); Text(player.position, color = Muted, fontSize = 10.sp) }
        Text("★ ${player.rating}", color = Gold, fontSize = 11.sp)
        Icon(Icons.Default.ChevronLeft, null, tint = Muted)
    }
}

@Composable
private fun PlayerStat(label: String, value: String, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(14.dp)).padding(12.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(value, color = Gold, fontSize = 20.sp, fontWeight = FontWeight.Black)
        Text(label, color = Muted, fontSize = 10.sp)
    }
}

private data class FootKingNews(
    val title: String,
    val category: String,
    val date: String,
    val summary: String,
    val body: String
)

@Composable
private fun NewsCenterScreen() {
    val articles = remember {
        listOf(
            FootKingNews("آماده‌سازی تیم‌ها برای هفته جدید لیگ", "لیگ ایران", "امروز", "تیم‌ها تمرین‌های خود را برای ادامه رقابت‌ها دنبال می‌کنند.", "در آستانه هفته جدید مسابقات، تیم‌ها برنامه تمرینی و فنی خود را پیگیری می‌کنند. ترکیب نهایی و وضعیت بازیکنان هر تیم پس از اعلام رسمی باشگاه‌ها مشخص خواهد شد. این متن نمونه‌ای برای نمایش قالب خبر در اپلیکیشن فوت کینگ است."),
            FootKingNews("نگاهی به آمار برترین گلزنان فصل", "آمار و اطلاعات", "دیروز", "مروری بر عملکرد مهاجمان در رقابت‌های این فصل.", "آمار گلزنان یکی از بخش‌های جذاب هر فصل فوتبالی است. در نسخه نهایی، اطلاعات این صفحه از منبع داده معتبر دریافت و پس از بررسی منتشر خواهد شد. اعداد و نام‌های واقعی در این نمونه درج نشده‌اند."),
            FootKingNews("آخرین خبرهای نقل‌وانتقالات فوتبال", "نقل‌وانتقالات", "۲ روز پیش", "مروری بر خبرهای نقل‌وانتقالات و اطلاعیه‌های رسمی.", "در این بخش خبرهای نقل‌وانتقالات از منابع معتبر گردآوری می‌شود. هر خبر باید منبع و زمان انتشار مشخص داشته باشد تا از انتشار شایعات تأییدنشده جلوگیری شود."),
            FootKingNews("نگاهی به رقابت‌های فوتبال اروپا", "فوتبال جهان", "۳ روز پیش", "مروری کوتاه بر رقابت‌های باشگاهی اروپا.", "این صفحه نمونه‌ای از قالب خبرهای فوتبال جهان است. پس از اتصال سرویس اخبار، متن کامل، تصویر، منبع و زمان انتشار به‌صورت پویا نمایش داده می‌شوند.")
        )
    }
    var category by remember { mutableStateOf("همه") }
    var selectedArticle by remember { mutableStateOf<FootKingNews?>(null) }
    var favorites by remember { mutableStateOf(setOf<String>()) }
    val categories = listOf("همه", "لیگ ایران", "فوتبال جهان", "نقل‌وانتقالات", "آمار و اطلاعات")
    Column(verticalArrangement = Arrangement.spacedBy(13.dp)) {
        if (selectedArticle == null) {
            Text("اخبار فوتبال", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
            Text("تازه‌ترین خبرها و گزارش‌های فوت کینگ", color = Muted, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(7.dp), modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState())) {
                categories.forEach { item ->
                    FilterChip(selected = category == item, onClick = { category = item }, label = { Text(item, fontSize = 10.sp) },
                        colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Gold, selectedLabelColor = Ink, labelColor = Muted))
                }
            }
            val filtered = articles.filter { category == "همه" || it.category == category }
            filtered.forEach { article ->
                Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(17.dp)).clickable { selectedArticle = article }.padding(15.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text(article.category, color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                        Text(article.date, color = Muted, fontSize = 10.sp)
                    }
                    Text(article.title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    Text(article.summary, color = Muted, fontSize = 11.sp, lineHeight = 18.sp)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                        Text("مطالعه خبر  ←", color = Gold, fontSize = 10.sp)
                        IconButton(onClick = { favorites = if (article.title in favorites) favorites - article.title else favorites + article.title }) {
                            Icon(if (article.title in favorites) Icons.Default.Bookmark else Icons.Default.BookmarkBorder, contentDescription = "ذخیره خبر", tint = Gold)
                        }
                    }
                }
            }
            Text("خبرهای این صفحه نمونه و آزمایشی هستند؛ هنوز از سرویس خبری دریافت نمی‌شوند.", color = Muted, fontSize = 10.sp, lineHeight = 16.sp)
            Text("خبرهای ذخیره‌شده: ${favorites.size}", color = Gold, fontSize = 11.sp)
        } else {
            TextButton(onClick = { selectedArticle = null }) { Text("→ بازگشت به اخبار", color = Gold) }
            Text(selectedArticle!!.category, color = Gold, fontSize = 11.sp)
            Text(selectedArticle!!.title, color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, lineHeight = 29.sp)
            Text(selectedArticle!!.date, color = Muted, fontSize = 10.sp)
            Divider(color = Color(0xFF343A45))
            Text(selectedArticle!!.body, color = Color.White, fontSize = 13.sp, lineHeight = 25.sp)
            Text("منبع: محتوای نمایشی فوت کینگ", color = Muted, fontSize = 10.sp)
            Button(onClick = { val title = selectedArticle!!.title; favorites = if (title in favorites) favorites - title else favorites + title },
                colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink), modifier = Modifier.fillMaxWidth()) {
                Icon(Icons.Default.Bookmark, null); Spacer(Modifier.width(7.dp)); Text(if (selectedArticle!!.title in favorites) "حذف از ذخیره‌شده‌ها" else "ذخیره خبر")
            }
        }
    }
}

@Composable private fun NewsCard(title: String, category: String, date: String) {
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
        Text(category, color = Gold, fontSize = 10.sp); Text(title, color = Color.White, fontSize = 14.sp, fontWeight = FontWeight.Bold); Text(date, color = Muted, fontSize = 10.sp)
    }
}


@Composable
private fun AuthPreviewScreen(activity: Activity) {
    var phone by remember { mutableStateOf("") }
    var code by remember { mutableStateOf("") }
    var codeStep by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf("") }
    var verificationId by remember { mutableStateOf<String?>(null) }
    var resendToken by remember { mutableStateOf<PhoneAuthProvider.ForceResendingToken?>(null) }
    var signedInUid by remember { mutableStateOf<String?>(null) }
    var displayName by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }

    fun authManagerOrNull(): PhoneAuthManager? = try {
        PhoneAuthManager()
    } catch (error: Exception) {
        message = "Firebase هنوز برای این برنامه پیکربندی نشده است. فایل تنظیمات پروژه لازم است."
        null
    }

    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp)).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Box(Modifier.size(58.dp).background(Color(0xFF28251D), CircleShape), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.Person, null, tint = Gold, modifier = Modifier.size(30.dp))
        }
        Text("حساب کاربری فوت کینگ", color = Gold, fontSize = 20.sp, fontWeight = FontWeight.ExtraBold)
        if (signedInUid != null) {
            Text("ورود با موفقیت انجام شد", color = Color.White, fontWeight = FontWeight.Bold)
            Text("شناسه کاربر: ${signedInUid!!.take(12)}…", color = Muted, fontSize = 11.sp)
            OutlinedTextField(value = displayName, onValueChange = { displayName = it.take(30) }, modifier = Modifier.fillMaxWidth(), label = { Text("نام نمایشی") }, singleLine = true, colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Gold, focusedLabelColor = Gold, cursorColor = Gold, unfocusedTextColor = Color.White, focusedTextColor = Color.White))
            Button(onClick = {
                val manager = authManagerOrNull()
                if (manager != null) manager.updateDisplayName(displayName) { ok, error -> message = if (ok) "نام نمایشی ذخیره شد." else (error ?: "ذخیره نام ناموفق بود") }
            }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)) { Text("ذخیره نام نمایشی") }
            Button(onClick = {
                try {
                    PhoneAuthManager().signOut()
                    signedInUid = null; displayName = ""; codeStep = false; code = ""; verificationId = null
                    message = "از حساب خارج شدی."
                } catch (_: Exception) { message = "خروج از حساب انجام نشد." }
            }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)) { Text("خروج از حساب") }
        } else {
            Text("برای ذخیره پیش‌بینی‌ها و امتیازها، با شماره موبایل وارد شو.", color = Muted, fontSize = 12.sp, lineHeight = 20.sp)
            if (!codeStep) {
                OutlinedTextField(value = phone, onValueChange = { phone = it.filter(Char::isDigit).take(11) }, modifier = Modifier.fillMaxWidth(), label = { Text("شماره موبایل") }, placeholder = { Text("09xxxxxxxxx") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Phone), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Gold, focusedLabelColor = Gold, cursorColor = Gold, unfocusedTextColor = Color.White, focusedTextColor = Color.White))
                Button(enabled = !busy, onClick = {
                    if (!phone.matches(Regex("09[0-9]{9}"))) {
                        message = "شماره موبایل باید ۱۱ رقم و با 09 شروع شود."
                    } else {
                        val manager = authManagerOrNull()
                        if (manager != null) {
                            busy = true; message = "در حال درخواست کد تأیید…"
                            manager.requestCode(activity, "+98${phone.drop(1)}", object : PhoneAuthManager.Callback {
                                override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken?) {
                                    verificationId = id; resendToken = token; codeStep = true; busy = false
                                    message = "کد تأیید ارسال شد. پیامک را بررسی کن."
                                }
                                override fun onVerified() {
                                    signedInUid = manager.currentUserId(); displayName = manager.currentDisplayName().orEmpty(); busy = false; message = "شماره موبایل به‌صورت خودکار تأیید شد."
                                }
                                override fun onFailure(messageText: String) { busy = false; message = messageText }
                            })
                        }
                    }
                }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)) { Text(if (busy) "لطفاً صبر کن…" else "ارسال کد تأیید") }
            } else {
                Text("کد تأیید برای شماره $phone", color = Color.White, fontWeight = FontWeight.Bold)
                OutlinedTextField(value = code, onValueChange = { code = it.filter(Char::isDigit).take(6) }, modifier = Modifier.fillMaxWidth(), label = { Text("کد تأیید") }, placeholder = { Text("کد ۶ رقمی") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = androidx.compose.ui.text.input.KeyboardType.Number), colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Gold, focusedLabelColor = Gold, cursorColor = Gold, unfocusedTextColor = Color.White, focusedTextColor = Color.White))
                Button(enabled = !busy, onClick = {
                    val id = verificationId
                    val manager = authManagerOrNull()
                    if (id == null) message = "ابتدا کد تأیید را درخواست کن."
                    else if (manager != null) {
                        busy = true
                        manager.confirmCode(id, code, object : PhoneAuthManager.Callback {
                            override fun onCodeSent(verificationId: String, resendToken: PhoneAuthProvider.ForceResendingToken?) {}
                            override fun onVerified() { signedInUid = manager.currentUserId(); displayName = manager.currentDisplayName().orEmpty(); busy = false; message = "ورود با موفقیت انجام شد." }
                            override fun onFailure(messageText: String) { busy = false; message = messageText }
                        })
                    }
                }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)) { Text(if (busy) "در حال بررسی…" else "تأیید و ورود") }
                TextButton(onClick = {
                    val manager = authManagerOrNull()
                    if (manager != null) {
                        busy = true
                        manager.requestCode(activity, "+98${phone.drop(1)}", object : PhoneAuthManager.Callback {
                            override fun onCodeSent(id: String, token: PhoneAuthProvider.ForceResendingToken?) { verificationId = id; resendToken = token; busy = false; message = "کد جدید ارسال شد." }
                            override fun onVerified() { signedInUid = manager.currentUserId(); busy = false }
                            override fun onFailure(messageText: String) { busy = false; message = messageText }
                        }, resendToken)
                    }
                }) { Text("ارسال مجدد کد", color = Gold) }
                TextButton(onClick = { codeStep = false; code = ""; verificationId = null; message = "" }) { Text("ویرایش شماره موبایل", color = Gold) }
            }
        }
        if (message.isNotBlank()) Text(message, color = Gold, fontSize = 11.sp, lineHeight = 17.sp)
        Text("برای کارکرد واقعی، پروژه Firebase باید تنظیم و ورود پیامکی در کنسول فعال شود.", color = Muted, fontSize = 10.sp, lineHeight = 16.sp)
    }
}


@Composable
private fun ProfileDashboardScreen(activity: Activity) {
    val demoPoints = 420
    val nextLevelPoints = 600
    val progress = demoPoints.toFloat() / nextLevelPoints.toFloat()
    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(22.dp)).padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Box(Modifier.size(58.dp).background(Color(0xFF28251D), CircleShape), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Person, null, tint = Gold, modifier = Modifier.size(32.dp))
                }
                Column(Modifier.weight(1f)) {
                    Text("بازیکن فوت کینگ", color = Color.White, fontSize = 17.sp, fontWeight = FontWeight.Bold)
                    Text("کاربر مهمان • پروفایل نمایشی", color = Muted, fontSize = 11.sp)
                }
                Icon(Icons.Default.EmojiEvents, null, tint = Gold, modifier = Modifier.size(28.dp))
            }
            Divider(color = Color(0xFF303744))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column { Text("سطح فعلی", color = Muted, fontSize = 11.sp); Text("سطح ۲ • هوادار", color = Gold, fontWeight = FontWeight.Bold) }
                Column(horizontalAlignment = Alignment.End) { Text("امتیاز", color = Muted, fontSize = 11.sp); Text("$demoPoints", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Black) }
            }
            LinearProgressIndicator(progress = { progress }, modifier = Modifier.fillMaxWidth().height(8.dp), color = Gold, trackColor = Color(0xFF303744))
            Text("${nextLevelPoints - demoPoints} امتیاز تا سطح بعدی", color = Muted, fontSize = 10.sp)
        }
        Text("عملکرد پیش‌بینی‌ها", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Row(horizontalArrangement = Arrangement.spacedBy(9.dp)) {
            ProfileStatCard("پیش‌بینی‌ها", "۲۴", Icons.Default.SportsSoccer, Modifier.weight(1f))
            ProfileStatCard("نتیجه درست", "۱۵", Icons.Default.CheckCircle, Modifier.weight(1f))
            ProfileStatCard("رتبه", "۴۲", Icons.Default.Leaderboard, Modifier.weight(1f))
        }
        Text("جدول برترین پیش‌بینی‌کنندگان", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        LeaderboardPreviewScreen()
        Text("نشان‌های افتخار", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            BadgeRow(Icons.Default.Star, "شروع قدرتمند", "اولین پیش‌بینی ثبت‌شده", true)
            BadgeRow(Icons.Default.EmojiEvents, "چشم تیزبین", "۱۰ پیش‌بینی با نتیجه درست", true)
            BadgeRow(Icons.Default.LocalFireDepartment, "هوادار پیگیر", "۷ روز فعالیت متوالی", false)
        }
        Text("حساب کاربری", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            ProfileMenuRow(Icons.Default.Person, "ورود یا ثبت‌نام", "برای ذخیره امتیازها و پیش‌بینی‌ها")
            Divider(color = Color(0xFF303744))
            ProfileMenuRow(Icons.Default.Notifications, "تنظیمات اعلان‌ها", "مدیریت خبرها و یادآوری مسابقات")
            Divider(color = Color(0xFF303744))
            ProfileMenuRow(Icons.Default.Settings, "تنظیمات برنامه", "زبان و ظاهر برنامه")
        }
        Text("اطلاعات این صفحه نمونه و آزمایشی است؛ امتیازها و نشان‌های واقعی پس از اتصال حساب و سرور نمایش داده می‌شوند.", color = Muted, fontSize = 10.sp, lineHeight = 17.sp)
        AuthPreviewScreen(activity)
        ProfileEditorCard()
    }
}


@Composable
private fun ProfileEditorCard() {
    val repository = remember { try { ProfileRepository() } catch (_: Exception) { null } }
    var displayName by remember { mutableStateOf("") }
    var username by remember { mutableStateOf("") }
    var bio by remember { mutableStateOf("") }
    var favoriteTeam by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("پس از ورود، اطلاعات پروفایل را تکمیل کن.") }
    var busy by remember { mutableStateOf(false) }

    LaunchedEffect(repository) {
        repository?.load { profile, error ->
            if (profile != null) {
                displayName = profile.displayName
                username = profile.username
                bio = profile.bio
                favoriteTeam = profile.favoriteTeam
                message = "اطلاعات پروفایل دریافت شد."
            } else if (error != null) message = error
        }
    }

    Column(
        Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Text("تکمیل پروفایل", color = Gold, fontWeight = FontWeight.Bold, fontSize = 16.sp)
        Text("نام نمایشی، نام کاربری و تیم محبوبت را ثبت کن.", color = Muted, fontSize = 11.sp)
        OutlinedTextField(value = displayName, onValueChange = { displayName = it.take(30) }, label = { Text("نام نمایشی") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = username, onValueChange = { username = it.filter { ch -> ch.isLetterOrDigit() || ch == '_' }.take(20) }, label = { Text("نام کاربری انگلیسی") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = favoriteTeam, onValueChange = { favoriteTeam = it.take(40) }, label = { Text("تیم محبوب") }, singleLine = true, modifier = Modifier.fillMaxWidth())
        OutlinedTextField(value = bio, onValueChange = { bio = it.take(120) }, label = { Text("درباره من (اختیاری)") }, minLines = 2, maxLines = 3, modifier = Modifier.fillMaxWidth())
        Button(
            onClick = {
                if (repository == null) {
                    message = "Firebase آماده نیست؛ تنظیمات پروژه را بررسی کن."
                } else {
                    busy = true
                    repository.save(ProfileRepository.Profile(displayName, username, bio, favoriteTeam)) { ok, result ->
                        busy = false
                        message = result ?: if (ok) "ذخیره شد" else "ذخیره ناموفق بود"
                    }
                }
            },
            enabled = !busy,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)
        ) {
            if (busy) CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Ink, strokeWidth = 2.dp)
            else Text("ذخیره پروفایل")
        }
        Text(message, color = Muted, fontSize = 10.sp, lineHeight = 16.sp)
    }
}


private data class AdminMatchItem(val home: String, val away: String, val competition: String, val dateTime: String, val status: String, val score: String)

@Composable
private fun AdminPanelScreen(onBack: () -> Unit) {
    val matches = remember { mutableStateListOf(
        AdminMatchItem("پرسپولیس", "استقلال", "لیگ برتر", "جمعه • ۱۹:۳۰", "برنامه‌ریزی‌شده", "— : —"),
        AdminMatchItem("سپاهان", "تراکتور", "لیگ برتر", "شنبه • ۱۸:۰۰", "برنامه‌ریزی‌شده", "— : —")
    ) }
    var home by remember { mutableStateOf("") }
    var away by remember { mutableStateOf("") }
    var competition by remember { mutableStateOf("لیگ برتر") }
    var dateTime by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("برنامه‌ریزی‌شده") }
    var score by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    Column(verticalArrangement = Arrangement.spacedBy(13.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowForward, "بازگشت", tint = Gold) }
            Column { Text("پنل مدیریت", color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold); Text("مدیریت مسابقات و نتایج", color = Muted, fontSize = 10.sp) }
        }
        Row(Modifier.fillMaxWidth().background(Color(0xFF302719), RoundedCornerShape(12.dp)).padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Icon(Icons.Default.Info, null, tint = Gold)
            Text("این پنل فعلاً نمایشی است؛ اطلاعات فقط تا زمان بسته‌شدن برنامه در حافظه می‌ماند و دسترسی آن هنوز امن‌سازی نشده است.", color = Color.White, fontSize = 10.sp, lineHeight = 16.sp)
        }
        Text("افزودن مسابقه", color = Gold, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
            AdminInput(home, { home = it }, "نام تیم میزبان")
            AdminInput(away, { away = it }, "نام تیم میهمان")
            AdminInput(competition, { competition = it }, "نام لیگ یا رقابت")
            AdminInput(dateTime, { dateTime = it }, "تاریخ و ساعت مسابقه")
            Text("وضعیت مسابقه", color = Muted, fontSize = 11.sp)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("برنامه‌ریزی‌شده", "زنده", "پایان‌یافته", "لغوشده").forEach { option ->
                    FilterChip(selected = status == option, onClick = { status = option }, label = { Text(option, fontSize = 9.sp) }, colors = FilterChipDefaults.filterChipColors(selectedContainerColor = Gold, selectedLabelColor = Ink))
                }
            }
            AdminInput(score, { score = it }, "نتیجه، مثال: ۲ - ۱")
            Button(onClick = {
                if (home.isBlank() || away.isBlank() || competition.isBlank() || dateTime.isBlank()) message = "نام دو تیم، رقابت و زمان مسابقه را کامل کن."
                else {
                    matches.add(0, AdminMatchItem(home.trim(), away.trim(), competition.trim(), dateTime.trim(), status, score.ifBlank { "— : —" }))
                    home = ""; away = ""; dateTime = ""; score = ""; status = "برنامه‌ریزی‌شده"
                    message = "مسابقه به فهرست آزمایشی اضافه شد."
                }
            }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)) { Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("ثبت مسابقه") }
            if (message.isNotBlank()) Text(message, color = Gold, fontSize = 10.sp)
        }
        Text("مسابقات ثبت‌شده (${matches.size})", color = Color.White, fontSize = 15.sp, fontWeight = FontWeight.Bold)
        matches.forEachIndexed { index, match ->
            Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(14.dp)).padding(13.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(match.competition, color = Gold, fontSize = 10.sp)
                    Text(match.status, color = Muted, fontSize = 10.sp)
                }
                Text("${match.home}  •  ${match.score}  •  ${match.away}", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Text(match.dateTime, color = Muted, fontSize = 10.sp)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                    TextButton(onClick = { matches.removeAt(index) }) { Icon(Icons.Default.DeleteOutline, null, tint = Color(0xFFE07A7A)); Text("حذف از فهرست آزمایشی", color = Color(0xFFE07A7A), fontSize = 10.sp) }
                }
            }
        }
    }
}

@Composable
private fun AdminInput(value: String, onValueChange: (String) -> Unit, label: String) {
    OutlinedTextField(value = value, onValueChange = onValueChange, modifier = Modifier.fillMaxWidth(), label = { Text(label) }, singleLine = true,
        colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Gold, focusedLabelColor = Gold, cursorColor = Gold, unfocusedTextColor = Color.White, focusedTextColor = Color.White))
}

@Composable
private fun LeaderboardPreviewScreen() {
    var period by remember { mutableStateOf("هفتگی") }
    val weekly = listOf("آرمان" to 860, "علی" to 790, "پارسا" to 720, "بازیکن فوت کینگ" to 420, "محمد" to 380)
    val monthly = listOf("پارسا" to 2450, "آرمان" to 2310, "بازیکن فوت کینگ" to 1780, "علی" to 1650, "رضا" to 1420)
    val season = listOf("علی" to 8950, "پارسا" to 8420, "بازیکن فوت کینگ" to 6210, "آرمان" to 5980, "محمد" to 5210)
    val rows = when (period) { "ماهانه" -> monthly; "فصل" -> season; else -> weekly }
    Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(18.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
            listOf("هفتگی", "ماهانه", "فصل").forEachIndexed { index, label ->
                SegmentedButton(selected = period == label, onClick = { period = label }, shape = SegmentedButtonDefaults.itemShape(index = index, count = 3)) { Text(label, fontSize = 10.sp) }
            }
        }
        rows.forEachIndexed { index, entry ->
            Row(Modifier.fillMaxWidth().background(if (entry.first == "بازیکن فوت کینگ") Color(0xFF28251D) else Color.Transparent, RoundedCornerShape(10.dp)).padding(horizontal = 10.dp, vertical = 11.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("${index + 1}", color = if (index < 3) Gold else Muted, fontWeight = FontWeight.Black, fontSize = 14.sp)
                Column(Modifier.weight(1f)) {
                    Text(entry.first, color = Color.White, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    if (entry.first == "بازیکن فوت کینگ") Text("رتبه نمایشی شما", color = Gold, fontSize = 9.sp)
                }
                Text("${entry.second} امتیاز", color = Gold, fontWeight = FontWeight.Bold, fontSize = 11.sp)
            }
        }
        Text("رتبه‌بندی و امتیازها نمونه هستند و پس از اتصال سرور با اطلاعات واقعی کاربران جایگزین می‌شوند.", color = Muted, fontSize = 10.sp, lineHeight = 16.sp)
    }
}

@Composable
private fun ProfileStatCard(title: String, value: String, icon: ImageVector, modifier: Modifier = Modifier) {
    Column(modifier.background(Panel, RoundedCornerShape(14.dp)).padding(vertical = 13.dp, horizontal = 7.dp), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(5.dp)) {
        Icon(icon, null, tint = Gold, modifier = Modifier.size(20.dp))
        Text(value, color = Color.White, fontWeight = FontWeight.Bold, fontSize = 17.sp)
        Text(title, color = Muted, fontSize = 9.sp, textAlign = TextAlign.Center)
    }
}

@Composable
private fun BadgeRow(icon: ImageVector, title: String, description: String, unlocked: Boolean) {
    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(11.dp)) {
        Box(Modifier.size(42.dp).background(if (unlocked) Color(0xFF332D1F) else Color(0xFF252B35), CircleShape), contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = if (unlocked) Gold else Muted)
        }
        Column(Modifier.weight(1f)) {
            Text(title, color = if (unlocked) Color.White else Muted, fontWeight = FontWeight.Bold, fontSize = 12.sp)
            Text(description, color = Muted, fontSize = 10.sp)
        }
        Text(if (unlocked) "دریافت‌شده" else "قفل", color = if (unlocked) Gold else Muted, fontSize = 9.sp)
    }
}

@Composable
private fun ProfileMenuRow(icon: ImageVector, title: String, subtitle: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 9.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        Icon(icon, null, tint = Gold)
        Column(Modifier.weight(1f)) {
            Text(title, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(subtitle, color = Muted, fontSize = 10.sp)
        }
        Icon(Icons.Default.ChevronLeft, null, tint = Muted)
    }
}


@Composable
private fun PredictionCenterScreen() {
    var homeGoals by remember { mutableIntStateOf(1) }
    var awayGoals by remember { mutableIntStateOf(0) }
    var submitted by remember { mutableStateOf(false) }
    var notice by remember { mutableStateOf("") }

    Column(Modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("مرکز پیش‌بینی", color = Gold, fontSize = 21.sp, fontWeight = FontWeight.ExtraBold)
        Text("نتیجه مسابقه را پیش‌بینی کن و امتیاز فوت کینگ بگیر.", color = Muted, fontSize = 12.sp)
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(20.dp)).padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text("لیگ برتر ایران", color = Gold, fontSize = 11.sp)
                Text("مسابقه نمونه • جمعه ۱۹:۳۰", color = Muted, fontSize = 10.sp)
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceAround, verticalAlignment = Alignment.CenterVertically) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    TeamBadge("پرسپولیس")
                    Text("پرسپولیس", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    GoalStepper(value = homeGoals, enabled = !submitted, onChange = { homeGoals = it })
                }
                Text("-", color = Gold, fontSize = 25.sp, fontWeight = FontWeight.Black)
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    TeamBadge("استقلال")
                    Text("استقلال", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    GoalStepper(value = awayGoals, enabled = !submitted, onChange = { awayGoals = it })
                }
            }
            Button(onClick = { submitted = true; notice = "پیش‌بینی نمونه ثبت شد؛ برای ذخیره دائمی باید به حساب کاربری و سرور متصل شوی." }, enabled = !submitted,
                modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Gold, contentColor = Ink)) {
                Text(if (submitted) "پیش‌بینی ثبت‌شده در این نشست" else "ثبت پیش‌بینی")
            }
            if (notice.isNotBlank()) Text(notice, color = Gold, fontSize = 11.sp, lineHeight = 18.sp)
            if (submitted) TextButton(onClick = { submitted = false; notice = "" }, modifier = Modifier.align(Alignment.End)) { Text("ویرایش پیش‌بینی آزمایشی", color = Gold) }
        }
        Text("قوانین امتیازدهی", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            ScoringRule("پیش‌بینی دقیق نتیجه", "۸ امتیاز")
            ScoringRule("تشخیص نتیجه بازی (برد، مساوی یا باخت)", "۳ امتیاز")
            ScoringRule("پیش‌بینی نادرست", "۱ امتیاز")
            Text("در صورت پیش‌بینی دقیق، فقط ۸ امتیاز محاسبه می‌شود و با امتیاز ۳ جمع نمی‌شود.", color = Muted, fontSize = 10.sp, lineHeight = 17.sp)
        }
        Text("پیش‌بینی‌های من", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Column(Modifier.fillMaxWidth().background(Panel, RoundedCornerShape(16.dp)).padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
            Text(if (submitted) "پرسپولیس $homeGoals - $awayGoals استقلال" else "هنوز پیش‌بینی‌ای ثبت نکرده‌ای.", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text("این بخش فعلاً نمایشی است؛ پیش‌بینی‌ها روی سرور ذخیره نمی‌شوند.", color = Muted, fontSize = 10.sp)
        }
    }
}

@Composable
private fun GoalStepper(value: Int, enabled: Boolean, onChange: (Int) -> Unit) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
        IconButton(onClick = { onChange((value - 1).coerceAtLeast(0)) }, enabled = enabled) { Icon(Icons.Default.RemoveCircleOutline, null, tint = if (enabled) Gold else Muted) }
        Text(value.toString(), color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Black)
        IconButton(onClick = { onChange((value + 1).coerceAtMost(9)) }, enabled = enabled) { Icon(Icons.Default.AddCircleOutline, null, tint = if (enabled) Gold else Muted) }
    }
}

@Composable
private fun ScoringRule(label: String, points: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Color.White, fontSize = 11.sp)
        Text(points, color = Gold, fontSize = 12.sp, fontWeight = FontWeight.Bold)
    }
}
