package com.footking.app.data.profile

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore

/** Firestore profile storage. Requires Firebase configuration and deployed security rules. */
class ProfileRepository(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance(),
    private val db: FirebaseFirestore = FirebaseFirestore.getInstance()
) {
    data class Profile(
        val displayName: String = "",
        val username: String = "",
        val bio: String = "",
        val favoriteTeam: String = ""
    )

    fun load(onResult: (Profile?, String?) -> Unit) {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            onResult(null, "برای مشاهده و ویرایش پروفایل ابتدا وارد حساب شو")
            return
        }
        db.collection("profiles").document(uid).get()
            .addOnSuccessListener { snapshot ->
                val profile = Profile(
                    displayName = snapshot.getString("displayName").orEmpty(),
                    username = snapshot.getString("username").orEmpty(),
                    bio = snapshot.getString("bio").orEmpty(),
                    favoriteTeam = snapshot.getString("favoriteTeam").orEmpty()
                )
                onResult(profile, null)
            }
            .addOnFailureListener { onResult(null, it.localizedMessage ?: "دریافت پروفایل ناموفق بود") }
    }

    fun save(profile: Profile, onResult: (Boolean, String?) -> Unit) {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            onResult(false, "ابتدا وارد حساب کاربری شو")
            return
        }
        val cleanName = profile.displayName.trim()
        val cleanUsername = profile.username.trim().lowercase()
        val cleanBio = profile.bio.trim()
        val cleanTeam = profile.favoriteTeam.trim()
        if (cleanName.length !in 2..30) {
            onResult(false, "نام نمایشی باید بین ۲ تا ۳۰ نویسه باشد")
            return
        }
        if (!cleanUsername.matches(Regex("^[a-z0-9_]{3,20}$"))) {
            onResult(false, "نام کاربری باید ۳ تا ۲۰ حرف انگلیسی، عدد یا زیرخط باشد")
            return
        }
        if (cleanBio.length > 120 || cleanTeam.length > 40) {
            onResult(false, "توضیحات یا نام تیم بیش از حد طولانی است")
            return
        }
        val data = mapOf(
            "displayName" to cleanName,
            "username" to cleanUsername,
            "bio" to cleanBio,
            "favoriteTeam" to cleanTeam,
            "updatedAt" to FieldValue.serverTimestamp()
        )
        db.collection("profiles").document(uid).set(data, com.google.firebase.firestore.SetOptions.merge())
            .addOnSuccessListener { onResult(true, "پروفایل با موفقیت ذخیره شد") }
            .addOnFailureListener { onResult(false, it.localizedMessage ?: "ذخیره پروفایل ناموفق بود") }
    }
}
