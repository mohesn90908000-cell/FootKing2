package com.footking.app.auth

import android.app.Activity
import com.google.firebase.FirebaseException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.PhoneAuthCredential
import com.google.firebase.auth.PhoneAuthOptions
import com.google.firebase.auth.PhoneAuthProvider
import com.google.firebase.auth.UserProfileChangeRequest
import java.util.concurrent.TimeUnit

/** Firebase Phone Auth adapter. Requires a real Firebase project and configured app. */
class PhoneAuthManager(
    private val auth: FirebaseAuth = FirebaseAuth.getInstance()
) {
    interface Callback {
        fun onCodeSent(verificationId: String, resendToken: PhoneAuthProvider.ForceResendingToken?)
        fun onVerified()
        fun onFailure(message: String)
    }

    fun requestCode(
        activity: Activity,
        e164PhoneNumber: String,
        callback: Callback,
        resendToken: PhoneAuthProvider.ForceResendingToken? = null
    ) {
        val builder = PhoneAuthOptions.newBuilder(auth)
            .setPhoneNumber(e164PhoneNumber)
            .setTimeout(60L, TimeUnit.SECONDS)
            .setActivity(activity)
            .setCallbacks(object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
                override fun onVerificationCompleted(credential: PhoneAuthCredential) {
                    auth.signInWithCredential(credential)
                        .addOnSuccessListener { callback.onVerified() }
                        .addOnFailureListener { callback.onFailure(it.localizedMessage ?: "ورود ناموفق بود") }
                }

                override fun onVerificationFailed(exception: FirebaseException) {
                    callback.onFailure(exception.localizedMessage ?: "ارسال کد تأیید ناموفق بود")
                }

                override fun onCodeSent(
                    verificationId: String,
                    token: PhoneAuthProvider.ForceResendingToken
                ) {
                    callback.onCodeSent(verificationId, token)
                }
            })
        if (resendToken != null) builder.setForceResendingToken(resendToken)
        PhoneAuthProvider.verifyPhoneNumber(builder.build())
    }

    fun confirmCode(verificationId: String, smsCode: String, callback: Callback) {
        if (smsCode.length != 6 || !smsCode.all(Char::isDigit)) {
            callback.onFailure("کد تأیید باید ۶ رقم باشد")
            return
        }
        val credential = PhoneAuthProvider.getCredential(verificationId, smsCode)
        auth.signInWithCredential(credential)
            .addOnSuccessListener { callback.onVerified() }
            .addOnFailureListener { callback.onFailure(it.localizedMessage ?: "کد تأیید معتبر نیست") }
    }

    fun updateDisplayName(name: String, onResult: (Boolean, String?) -> Unit) {
        val user = auth.currentUser
        if (user == null) {
            onResult(false, "ابتدا وارد حساب کاربری شو")
            return
        }
        val cleanName = name.trim()
        if (cleanName.length !in 2..30) {
            onResult(false, "نام نمایشی باید بین ۲ تا ۳۰ نویسه باشد")
            return
        }
        val request = UserProfileChangeRequest.Builder().setDisplayName(cleanName).build()
        user.updateProfile(request)
            .addOnSuccessListener { onResult(true, null) }
            .addOnFailureListener { onResult(false, it.localizedMessage ?: "ذخیره نام ناموفق بود") }
    }

    fun currentDisplayName(): String? = auth.currentUser?.displayName
    fun signOut() = auth.signOut()
    fun currentUserId(): String? = auth.currentUser?.uid
}
