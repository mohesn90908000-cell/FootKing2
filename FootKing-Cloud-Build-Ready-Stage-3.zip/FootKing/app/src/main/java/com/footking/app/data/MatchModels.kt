package com.footking.app.data

/** Data model for matches entered by admins or imported from a licensed football-data provider. */
enum class MatchSource { MANUAL, AUTOMATIC }
enum class MatchStatus { SCHEDULED, LIVE, FINISHED, POSTPONED, CANCELLED }

data class FootballMatch(
    val id: String,
    val externalId: String? = null,
    val competition: String,
    val homeTeam: String,
    val awayTeam: String,
    val kickoffUtc: String,
    val homeScore: Int? = null,
    val awayScore: Int? = null,
    val status: MatchStatus = MatchStatus.SCHEDULED,
    val source: MatchSource,
    val updatedAtEpochMillis: Long,
    /** Manual edits are authoritative until an admin explicitly clears the override. */
    val manuallyOverridden: Boolean = false
)

/**
 * Small deterministic merge layer. A provider match is matched by externalId first;
 * if unavailable, the stable local id is used. Manual overrides are never overwritten
 * by automatic imports. This is domain logic only; persistence/API wiring comes later.
 */
object MatchMergePolicy {
    fun merge(existing: List<FootballMatch>, incoming: List<FootballMatch>): List<FootballMatch> {
        val result = existing.toMutableList()
        incoming.forEach { candidate ->
            val index = result.indexOfFirst { current ->
                (candidate.externalId != null && current.externalId == candidate.externalId) ||
                    current.id == candidate.id
            }
            if (index < 0) {
                result += candidate
            } else {
                val current = result[index]
                result[index] = when {
                    current.manuallyOverridden && candidate.source == MatchSource.AUTOMATIC -> current
                    candidate.updatedAtEpochMillis >= current.updatedAtEpochMillis -> candidate
                    else -> current
                }
            }
        }
        return result.sortedBy { it.kickoffUtc }
    }
}
