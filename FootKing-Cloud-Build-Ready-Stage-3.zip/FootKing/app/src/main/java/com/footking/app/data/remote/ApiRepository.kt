package com.footking.app.data.remote

import com.footking.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

sealed class ApiConnectionState {
    object Connected : ApiConnectionState()
    object Unavailable : ApiConnectionState()
    object NotConfigured : ApiConnectionState()
}

/** Performs a lightweight health check without blocking the Android main thread. */
class ApiRepository(
    private val api: FootKingApi = ApiClient.api
) {
    suspend fun checkConnection(): ApiConnectionState = withContext(Dispatchers.IO) {
        if (BuildConfig.API_BASE_URL.contains("api.example.com")) {
            return@withContext ApiConnectionState.NotConfigured
        }
        try {
            val response = api.health()
            if (response.isSuccessful) ApiConnectionState.Connected
            else ApiConnectionState.Unavailable
        } catch (_: Exception) {
            ApiConnectionState.Unavailable
        }
    }
}
