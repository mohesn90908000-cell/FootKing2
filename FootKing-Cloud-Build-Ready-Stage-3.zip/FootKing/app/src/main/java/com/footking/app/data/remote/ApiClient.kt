package com.footking.app.data.remote

import com.footking.app.BuildConfig
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/** Central Retrofit client. The API URL is supplied through Gradle configuration. */
object ApiClient {
    private val loggingInterceptor = HttpLoggingInterceptor().apply {
        level = if (BuildConfig.DEBUG) HttpLoggingInterceptor.Level.BASIC
        else HttpLoggingInterceptor.Level.NONE
        redactHeader("Authorization")
        redactHeader("Cookie")
        redactHeader("Set-Cookie")
    }

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(15, TimeUnit.SECONDS)
            .readTimeout(20, TimeUnit.SECONDS)
            .writeTimeout(20, TimeUnit.SECONDS)
            .addInterceptor(loggingInterceptor)
            .build()
    }

    val api: FootKingApi by lazy {
        val baseUrl = BuildConfig.API_BASE_URL
        require(baseUrl.endsWith("/")) {
            "FOOTKING_API_BASE_URL must end with /"
        }
        require(baseUrl.startsWith("https://") ||
            (BuildConfig.DEBUG && baseUrl.startsWith("http://10.0.2.2")) ||
            (BuildConfig.DEBUG && baseUrl.startsWith("http://192.168.")) ||
            (BuildConfig.DEBUG && baseUrl.startsWith("http://10."))) {
            "Use HTTPS for production. HTTP is permitted only for local debug builds."
        }

        Retrofit.Builder()
            .baseUrl(baseUrl)
            .client(httpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
            .create(FootKingApi::class.java)
    }
}
