# Foot King — Admin Match Management UI Stage

## Added
- Added a demo admin panel entry from the Profile tab.
- Added a form for match home/away teams, competition, date/time, status, and score.
- Added an in-memory list of matches and a demo remove action.
- Preserved the black/gold visual style and Persian RTL layout.

## Important limitations
- This is UI/prototype functionality only. It does not authenticate an administrator.
- Match data is held in Compose memory and is lost when the app process is closed.
- The panel is currently reachable from the profile screen for demonstration. It must be protected by server-side authentication and authorization before any real release.
- No backend write API, database persistence, or live sports provider is connected by this stage.
- This source archive has not been compiled or device-tested in this environment.
