# Match Details Stage

Added a selectable match list and a match detail screen in the Matches tab.
The detail screen includes a match header, placeholder score/status, sample statistics,
events area, and lineup area. All match information remains local/demo content.
No live scores, official lineups, event feed, API endpoints, persistence, or backend
integration were added. This stage has not been compiled or tested on a device.
