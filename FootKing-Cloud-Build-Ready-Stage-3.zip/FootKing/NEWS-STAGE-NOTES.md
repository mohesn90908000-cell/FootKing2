# FootKing News UI Stage

This stage continues from FootKing-Leaderboard-Stage.zip.

Added to the News tab:
- Persian RTL news center
- category filters (horizontal scrolling)
- sample news list and article detail view
- save/unsave article state in memory for the current app session
- back navigation from article detail

Important limitations:
- News content is placeholder/sample content, not current factual reporting.
- No news API, remote images, backend persistence, or user account sync is connected.
- Favorites are in-memory only and reset when the app process is restarted.
- Android build was not run because Gradle is unavailable in this environment.
