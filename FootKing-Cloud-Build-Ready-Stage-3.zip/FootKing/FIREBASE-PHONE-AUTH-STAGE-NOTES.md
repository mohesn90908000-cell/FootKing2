# FOOT KING — Firebase Phone Authentication Stage

## Added in this stage
- Added Firebase BoM and Firebase Authentication Android dependency.
- Added `PhoneAuthManager` adapter for requesting an SMS verification code, confirming a six-digit code, automatic phone verification callback, sign-out, and reading the authenticated Firebase UID.
- Kept the existing login screen clearly marked as a demo; it does not falsely claim that an SMS was sent.

## Required owner setup before runtime use
1. Create/select the real Firebase project and add Android app ID `com.footking.app`.
2. Enable Phone sign-in in Firebase Authentication.
3. Add the app SHA-1 and SHA-256 fingerprints in Firebase project settings.
4. Download the matching `google-services.json` into `app/`.
5. Configure the Google Services Gradle plugin using the version supported by the project's Android Gradle Plugin, then sync Gradle.
6. Configure allowed phone regions, quotas, billing/abuse protections, and test phone numbers in Firebase Console.
7. Integrate `PhoneAuthManager` into an Activity-aware UI flow and test on a real device.

## Security notes
- Phone sign-in authenticates a user; it does not make that user an administrator.
- The `admin: true` custom claim must be assigned only from a trusted server environment after verifying the project owner's identity. Never assign admin claims from the Android client and never embed service-account credentials in the app.
- Keep all admin writes behind the existing callable backend functions and Firestore rules.

## Not completed / not verified
- No Firebase project ID, `google-services.json`, SHA fingerprints, or phone-auth provider configuration were supplied.
- Existing Compose login preview is not yet wired to this manager; the new class is an integration layer only.
- No SMS was sent, no Firebase project was contacted, and no deployment occurred.
- Gradle build, emulator test, and device test were not run in this environment.
