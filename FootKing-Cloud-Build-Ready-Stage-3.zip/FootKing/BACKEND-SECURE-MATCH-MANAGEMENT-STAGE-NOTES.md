# FOOT KING — Secure Match Management Backend Stage

## Added
- Server callable `saveMatch` to create/update match documents.
- Server callable `deleteMatch` with admin authorization and a guard against deleting matches that have predictions.
- Shared server-side admin-claim check reused by `finalizeMatch`.
- Input validation for teams, competition, kickoff timestamp, status, and finished scores.
- Persian setup and deployment notes in `backend/README.md`.

## Not completed
- No Firebase project credentials/configuration were supplied; nothing was deployed.
- Android app does not yet call these callable functions.
- Firebase Authentication, SMS verification, and secure assignment of the `admin` custom claim are not configured.
- No build or emulator/device test was run in this environment.
