# FOOT KING — Login and Basic Profile Integration Stage

## Implemented
- Replaced the previous demo-only login form with an Activity-aware Firebase Phone Auth flow.
- Requests SMS verification for Iranian mobile numbers entered as `09xxxxxxxxx`, converting them to E.164 `+98...` format.
- Handles the Firebase code-sent callback, six-digit code confirmation, automatic verification callback, resend token, and sign-out.
- Shows the authenticated Firebase UID after sign-in.
- Adds a basic display-name editor and saves the name to the Firebase Authentication user profile.
- Shows a configuration message if Firebase is not initialized instead of pretending an SMS was sent.

## Still required from the project owner
- Add the real `google-services.json`, configure the Google Services Gradle plugin, enable Phone provider, and add SHA-1/SHA-256 fingerprints.
- Configure Firebase phone-auth region policy, quotas, and test numbers.
- Configure and deploy the trusted backend that assigns the `admin` custom claim. A verified phone number is not an admin role.
- Decide the Firestore user-profile schema before storing extra profile fields such as avatar, favorite team, or preferences.

## Limitations / verification
- This stage stores only Firebase Auth's display name. It does not yet save extended profile data in Firestore.
- The UI currently accepts Iranian mobile-number format only.
- No real Firebase project was available; no SMS was sent and no deployment was performed.
- No Gradle build, emulator test, or physical-device test was run in this environment.
