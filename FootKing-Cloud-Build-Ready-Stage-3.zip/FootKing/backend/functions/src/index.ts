import { initializeApp } from "firebase-admin/app";
import { FieldValue, getFirestore } from "firebase-admin/firestore";
import { CallableRequest, HttpsError, onCall } from "firebase-functions/v2/https";

initializeApp();
const db = getFirestore();
type Outcome = "HOME" | "DRAW" | "AWAY";
function outcome(h: number, a: number): Outcome { return h > a ? "HOME" : h < a ? "AWAY" : "DRAW"; }

/** FOOT KING approved scoring: exact 8, correct outcome 3, incorrect 1. */
export function predictionPoints(ph: number, pa: number, ah: number, aa: number): number {
  if (ph === ah && pa === aa) return 8;
  return outcome(ph, pa) === outcome(ah, aa) ? 3 : 1;
}



const MATCH_STATUSES = ["SCHEDULED", "LIVE", "FINISHED", "CANCELLED"] as const;
function requireAdmin(request: CallableRequest<unknown>) {
  if (!request.auth || request.auth.token.admin !== true) {
    throw new HttpsError("permission-denied", "فقط مدیر اصلی مجاز است.");
  }
}
function validText(value: unknown, max: number): value is string {
  return typeof value === "string" && value.trim().length > 0 && value.trim().length <= max;
}

/** Create or update a match. All writes are authorized and validated on the server. */
export const saveMatch = onCall(async (request) => {
  requireAdmin(request);
  const data = request.data ?? {};
  const { matchId, homeTeam, awayTeam, competition, kickoffUtc, status } = data;
  if (!validText(homeTeam, 80) || !validText(awayTeam, 80) ||
      !validText(competition, 100) || !validText(kickoffUtc, 40) ||
      !Number.isFinite(Date.parse(kickoffUtc)) ||
      !MATCH_STATUSES.includes(status)) {
    throw new HttpsError("invalid-argument", "اطلاعات مسابقه معتبر نیست.");
  }
  if (homeTeam.trim() === awayTeam.trim()) {
    throw new HttpsError("invalid-argument", "تیم میزبان و میهمان باید متفاوت باشند.");
  }
  const payload: Record<string, unknown> = {
    homeTeam: homeTeam.trim(), awayTeam: awayTeam.trim(),
    competition: competition.trim(), kickoffUtc: new Date(kickoffUtc).toISOString(),
    status, updatedAt: FieldValue.serverTimestamp()
  };
  if (status === "FINISHED") {
    if (!Number.isInteger(data.homeScore) || !Number.isInteger(data.awayScore) ||
        data.homeScore < 0 || data.awayScore < 0 || data.homeScore > 30 || data.awayScore > 30) {
      throw new HttpsError("invalid-argument", "برای مسابقه پایان‌یافته نتیجه معتبر وارد کنید.");
    }
    payload.homeScore = data.homeScore;
    payload.awayScore = data.awayScore;
  } else {
    payload.homeScore = null;
    payload.awayScore = null;
  }

  if (matchId !== undefined && (!validText(matchId, 120) || !/^[A-Za-z0-9_-]+$/.test(matchId))) {
    throw new HttpsError("invalid-argument", "شناسه مسابقه معتبر نیست.");
  }
  const ref = matchId ? db.collection("matches").doc(matchId) : db.collection("matches").doc();
  if (matchId) {
    const existing = await ref.get();
    if (!existing.exists) throw new HttpsError("not-found", "مسابقه پیدا نشد.");
    await ref.update(payload);
  } else {
    await ref.create({ ...payload, createdAt: FieldValue.serverTimestamp() });
  }
  return { ok: true, matchId: ref.id };
});

/** Delete a match only through an admin-authorized server call. */
export const deleteMatch = onCall(async (request) => {
  requireAdmin(request);
  const { matchId } = request.data ?? {};
  if (!validText(matchId, 120) || !/^[A-Za-z0-9_-]+$/.test(matchId)) {
    throw new HttpsError("invalid-argument", "شناسه مسابقه معتبر نیست.");
  }
  const ref = db.collection("matches").doc(matchId);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError("not-found", "مسابقه پیدا نشد.");
  const predictions = await db.collection("predictions").where("matchId", "==", matchId).limit(1).get();
  if (!predictions.empty) {
    throw new HttpsError("failed-precondition", "مسابقه دارای پیش‌بینی است؛ آن را حذف نکنید و وضعیتش را لغو کنید.");
  }
  await ref.delete();
  return { ok: true };
});

export const submitPrediction = onCall(async (request) => {
  if (!request.auth) throw new HttpsError("unauthenticated", "ابتدا وارد حساب شوید.");
  const { matchId, homeScore, awayScore } = request.data ?? {};
  if (typeof matchId !== "string" || !matchId.trim() ||
      !Number.isInteger(homeScore) || !Number.isInteger(awayScore) ||
      homeScore < 0 || awayScore < 0 || homeScore > 30 || awayScore > 30) {
    throw new HttpsError("invalid-argument", "اطلاعات پیش‌بینی معتبر نیست.");
  }
  const matchRef = db.collection("matches").doc(matchId);
  const predictionRef = db.collection("predictions").doc(`${matchId}_${request.auth.uid}`);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(matchRef);
    if (!snap.exists) throw new HttpsError("not-found", "مسابقه پیدا نشد.");
    const match = snap.data()!;
    const kickoff = Date.parse(match.kickoffUtc);
    if (!Number.isFinite(kickoff) || match.status !== "SCHEDULED" || Date.now() >= kickoff)
      throw new HttpsError("failed-precondition", "مهلت پیش‌بینی تمام شده است.");
    const prior = await tx.get(predictionRef);
    if (prior.exists) throw new HttpsError("already-exists", "برای این مسابقه قبلاً پیش‌بینی ثبت شده است.");
    tx.create(predictionRef, { matchId, userId: request.auth!.uid, homeScore, awayScore,
      points: null, scored: false, createdAt: FieldValue.serverTimestamp() });
  });
  return { ok: true };
});

export const finalizeMatch = onCall(async (request) => {
  requireAdmin(request);
  const { matchId, homeScore, awayScore } = request.data ?? {};
  if (typeof matchId !== "string" || !Number.isInteger(homeScore) || !Number.isInteger(awayScore) || homeScore < 0 || awayScore < 0)
    throw new HttpsError("invalid-argument", "نتیجه مسابقه معتبر نیست.");
  const matchRef = db.collection("matches").doc(matchId);
  await db.runTransaction(async tx => {
    const snap = await tx.get(matchRef);
    if (!snap.exists) throw new HttpsError("not-found", "مسابقه پیدا نشد.");
    tx.update(matchRef, { homeScore, awayScore, status: "FINISHED", finalizedAt: FieldValue.serverTimestamp() });
  });
  const predictions = await db.collection("predictions").where("matchId", "==", matchId).get();
  for (let i = 0; i < predictions.docs.length; i += 400) {
    const batch = db.batch();
    for (const doc of predictions.docs.slice(i, i + 400)) {
      const p = doc.data();
      if (p.scored === true) continue;
      const points = predictionPoints(p.homeScore, p.awayScore, homeScore, awayScore);
      batch.update(doc.ref, { points, scored: true, scoredAt: FieldValue.serverTimestamp() });
      batch.set(db.collection("profiles").doc(p.userId), {
        totalPredictionPoints: FieldValue.increment(points),
        predictionCount: FieldValue.increment(1), updatedAt: FieldValue.serverTimestamp()
      }, { merge: true });
    }
    await batch.commit();
  }
  return { ok: true, scoredPredictions: predictions.size };
});
