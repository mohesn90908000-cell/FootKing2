# Cloud Build Stage

Added a GitHub Actions workflow to build `:app:assembleDebug` on Ubuntu with JDK 17, Gradle 8.9, and Android SDK Platform 35, then upload the debug APK as a 14-day artifact.

This is build automation setup only. No remote build has been run from this workspace, so compilation success and APK availability are not claimed. The repository must be uploaded to GitHub and the workflow executed by the user. Firebase project configuration is still external and required for live authentication/Firestore.
